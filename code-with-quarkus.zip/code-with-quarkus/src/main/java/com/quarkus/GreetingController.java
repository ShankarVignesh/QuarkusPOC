package com.quarkus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quarkus.service.ServiceInterface;

@RestController
@RequestMapping("/greeting")
public class GreetingController {

	@Autowired
	@Qualifier("serviceOne")
	private ServiceInterface serviceInterface; 
	
    @GetMapping
    public String hello() {
        return serviceInterface.hello();
    }
}
