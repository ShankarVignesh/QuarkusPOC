package com.quarkus.service;

public interface ServiceInterface {

	public String hello();
}
