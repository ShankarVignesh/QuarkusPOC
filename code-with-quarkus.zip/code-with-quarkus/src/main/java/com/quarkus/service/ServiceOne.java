package com.quarkus.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceOne implements ServiceInterface {

	@Override
	public String hello() {
        return "Hello ServiceOne";
    }
}
