package com.quarkus.service;

import org.springframework.stereotype.Service;

@Service
public class ServiceTwo implements ServiceInterface {

	@Override
	public String hello() {
        return "Hello ServiceTwo";
    }
}
